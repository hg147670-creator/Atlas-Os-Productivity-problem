#!/usr/bin/env python3
"""Regenerate skills.js from the plugin's SKILL.md files and write the icons. Run: python3 build.py [path/to/atlas-productivity]"""
import glob, json, os, re, struct, sys, zlib
here = os.path.dirname(os.path.abspath(__file__))
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "..", "atlas-productivity")
skills = []
for f in sorted(glob.glob(os.path.join(src, "skills", "*", "SKILL.md"))):
    t = open(f, encoding="utf-8").read()
    m = re.match(r"---\nname: (.+)\ndescription: (.+)\n---\n(.*)", t, re.S)
    skills.append({"name": m.group(1), "description": m.group(2), "body": m.group(3).strip()})
open(os.path.join(here, "skills.js"), "w", encoding="utf-8").write("window.ATLAS_SKILLS=" + json.dumps(skills, ensure_ascii=False) + ";\n")
print(len(skills), "skills ->", "skills.js")
def png(path, n, maskable):
    cx = cy = n / 2; R = n * (0.26 if maskable else 0.36); rows = []
    for y in range(n):
        row = bytearray([0])
        for x in range(n):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if d < n * 0.07: c = (245, 166, 91)
            elif R - n * 0.045 < d < R: c = (245, 166, 91)
            else:
                k = y / n; c = (14 + int(8 * k), 17 + int(10 * k), 23 + int(18 * k))
            row += bytes(c)
        rows.append(bytes(row))
    def ch(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", n, n, 8, 2, 0, 0, 0)) + ch(b"IDAT", zlib.compress(b"".join(rows), 9)) + ch(b"IEND", b""))
for name, n, mk in (("icon-192.png", 192, False), ("icon-512.png", 512, False), ("icon-maskable-512.png", 512, True)):
    png(os.path.join(here, name), n, mk)
print("icons written")
