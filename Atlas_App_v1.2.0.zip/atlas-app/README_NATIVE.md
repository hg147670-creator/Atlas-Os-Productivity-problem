# Build Atlas as real apps

Nothing here was compiled or run by the author: building needs SDKs that are not available in the authoring environment. The steps below are standard Capacitor/Electron setups; the first run may need small fixes.

## Easiest: build in the cloud (no SDK on your PC)
1. Create a GitHub repo and upload this `atlas-app` folder as the repo root.
2. Actions tab > "Build Atlas apps" > Run workflow.
3. Download artifacts: `atlas-android-apk` (debug APK, sideload on Android) and `atlas-windows-installer` (.exe).

## On your own machine (Node 20+)
- Windows/Mac/Linux desktop: `npm install` then `npm run desktop` (run) or `npm run dist:win` / `dist:mac` / `dist:linux` (installer in `dist/`; build each OS on that OS).
- Android: install Android Studio + JDK 17, then `npm install && npm run prep && npx cap add android && npx cap sync android && npx cap open android` and Run/Build APK.
- iOS: needs a Mac with Xcode and (to run on a real iPhone or publish) an Apple Developer account: `npm install && npm run prep && npx cap add ios && npx cap sync ios && npx cap open ios`.

## Known limits
- Phone WebViews may pause timers, notifications, wake lock and sound when the app is in the background; the timer is computed from the end time so it stays correct, but the alert may be late.
- The Android APK is a debug build, not signed for the Play Store.
- API key stays on the device (see main README).
