const { app, BrowserWindow } = require('electron');
const path = require('path');
function create() {
  const w = new BrowserWindow({ width: 1100, height: 780, backgroundColor: '#0e1117', autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false } });
  w.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
}
app.whenReady().then(create);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) create(); });
