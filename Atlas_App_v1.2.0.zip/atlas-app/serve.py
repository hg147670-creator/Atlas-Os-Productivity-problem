#!/usr/bin/env python3
"""Local server: python3 serve.py  ->  http://localhost:8080 (localhost counts as secure, so install and service worker work)."""
import http.server, socketserver, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
with socketserver.TCPServer(("", 8080), http.server.SimpleHTTPRequestHandler) as s:
    print("http://localhost:8080"); s.serve_forever()
