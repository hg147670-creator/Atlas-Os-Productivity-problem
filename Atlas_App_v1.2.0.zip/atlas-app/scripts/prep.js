// Copies the web app into www/ (used by Capacitor and Electron).
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out);
for (const f of ['index.html', 'skills.js', 'manifest.webmanifest', 'sw.js', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png'])
  fs.copyFileSync(path.join(root, f), path.join(out, f));
console.log('www/ ready');
