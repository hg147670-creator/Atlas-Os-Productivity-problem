#!/usr/bin/env python3
"""Generate every platform manifest from manifest.source.json (single source of truth).
Run from the plugin root:  python scripts/sync_manifests.py"""
import json, os
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = json.load(open(os.path.join(root, "manifest.source.json"), encoding="utf-8"))

def dump(rel, obj):
    p = os.path.join(root, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2); f.write("\n")
    print("wrote", rel)

base = {k: src[k] for k in ("name", "version", "description", "author", "keywords")}
# Claude (Claude Code / Cowork): skills/ and commands/ are auto-discovered
dump(".claude-plugin/plugin.json", base)
iface = {"capabilities": ["Interactive"], "category": src["category"], "defaultPrompt": src["defaultPrompt"],
         "developerName": src["author"]["name"], "displayName": src["displayName"],
         "longDescription": src["longDescription"], "shortDescription": src["shortDescription"]}
# Codex / ChatGPT
dump(".codex-plugin/plugin.json", {**base, "interface": iface, "skills": "./skills", "mcpServers": "./.mcp.json"})
# Generic agent-plugins manifest (kept for compatibility with the original package)
dump("plugin.json", {"$schema": "https://agent-plugins.org/schemas/1.0.0/plugin.schema.json", **base,
                     "extensions": {"com.openai": {"interface": iface}}})
