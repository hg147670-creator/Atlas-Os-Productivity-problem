#!/usr/bin/env python3
"""Smoke-test all bundled scripts with sample data. Run from plugin root: python scripts/selftest.py"""
import json, os, subprocess, sys, tempfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sk = lambda *p: os.path.join(root, "skills", *p)
def run(args, inp=None):
    r = subprocess.run([sys.executable] + args, input=inp, capture_output=True, text=True)
    assert r.returncode == 0, f"FAILED {args}\n{r.stdout}\n{r.stderr}"
    return r.stdout
with tempfile.TemporaryDirectory() as d:
    st = os.path.join(d, "atlas", "state.json")
    print(run([sk("productivity-os", "scripts", "state.py"), "init", "--path", st]).strip())
    print(run([sk("productivity-os", "scripts", "state.py"), "capture", "buy milk", "--path", st]).strip())
    data = json.load(open(st)); data["north_star"] = "Ship Atlas"
    data["habits"] = [{"id": "h1", "name": "Read", "target_per_week": 5, "log": ["2026-01-05", "2026-01-06", "2026-01-07"]}]
    data["projects"] = [{"id": "p1", "name": "Launch", "status": "active", "deadline": "2026-01-10", "next_action": "Draft page", "milestones": [{"title": "Alpha", "due": "2026-01-09", "done": False}]}]
    data["tasks"] = [{"id": "t1", "title": "Write report", "project": "p1", "est_min": 120, "status": "open", "due": "2026-01-08"}]
    json.dump(data, open(st, "w"))
    print(run([sk("productivity-os", "scripts", "state.py"), "habit-log", "h1", "2026-01-08", "--path", st]).strip())
    print(run([sk("productivity-os", "scripts", "state.py"), "validate", "--path", st]).strip())
    print(run([sk("productivity-os", "scripts", "state.py"), "summary", "--path", st]).strip())
    print(run([sk("habit-tracker", "scripts", "habit_stats.py"), "--state", st, "--today", "2026-01-08"]))
    out = os.path.join(d, "dash.html")
    print(run([sk("dashboard", "scripts", "build_dashboard.py"), "--state", st, "--out", out, "--today", "2026-01-08"]).strip())
    assert "Ship Atlas" in open(out).read()
    tasks = json.dumps([{"title": "Report", "est_min": 180}, {"title": "Email", "est_min": 60}, {"title": "Slides", "est_min": 120}])
    print(run([sk("daily-planning", "scripts", "capacity_check.py"), "--available-hours", "6"], tasks))
    ics = os.path.join(d, "day.ics")
    blocks = json.dumps([{"title": "Focus: report, part 1", "start": "2026-01-08T09:00", "duration_min": 50, "notes": "Draft; no email"}])
    print(run([sk("daily-planning", "scripts", "make_ics.py"), "--out", ics], blocks).strip())
    assert open(ics, newline="").read().count("\r\n") > 5
    # --- v0.3 additions: calendar, notion export, reviews
    events = json.dumps([{"title": "Standup", "start": "2026-01-08T09:30", "end": "2026-01-08T10:00"},
                         {"title": "Client call", "start": "2026-01-08T14:00", "end": "2026-01-08T15:00"},
                         {"title": "Holiday", "start": "2026-01-08", "end": "2026-01-09"}])
    fs = json.loads(run([sk("calendar-sync", "scripts", "free_slots.py"), "--date", "2026-01-08"], events))
    print(json.dumps(fs))
    assert fs["slots"][0]["start"] == "09:00" or fs["slots"][0]["start"] == "10:10", fs
    assert all(not (s["start"] < "15:00" and s["end"] > "13:50" and not (s["end"] <= "13:50")) for s in fs["slots"]), fs
    rules = os.path.join(d, "rules.json"); json.dump({"Work": ["client", "standup"], "Health": ["gym"]}, open(rules, "w"))
    ta = json.loads(run([sk("calendar-sync", "scripts", "time_audit.py"), "--rules", rules], events))
    print(json.dumps(ta)); assert ta["by_area_hours"]["Work"] == 1.5 and ta["all_day_skipped"] == 1, ta
    data = json.load(open(st)); data["reviews"] = [{"id": "r1", "period": "2026-Q4", "type": "quarterly", "result": "ok", "lesson": "less WIP", "next_goals": ["A", "B"]}]
    data["decisions"] = [{"id": "d1", "date": "2026-01-02", "decision": "Use SQLite", "why": "simple", "status": "open", "review_on": "2026-03-01"}]
    json.dump(data, open(st, "w"))
    print(run([sk("productivity-os", "scripts", "state.py"), "validate", "--path", st]).strip())
    outdir = os.path.join(d, "nx")
    print(run([sk("notion-sync", "scripts", "export_notion_csv.py"), "--state", st, "--out", outdir]).strip())
    assert "Atlas ID" in open(os.path.join(outdir, "tasks.csv")).read().splitlines()[0]
    assert os.path.exists(os.path.join(outdir, "reviews.csv"))
print("ALL OK")
