# Connect Notion

Notion hosts an official MCP server with OAuth, so no tokens are stored in this plugin.

**Server:** `https://mcp.notion.com/mcp` (Streamable HTTP; `https://mcp.notion.com/sse` only for clients without Streamable HTTP).

## Setup
- **Claude Code / Cowork:** the plugin's `.mcp.json` registers the `notion` server. On first use, complete the OAuth sign-in in your browser. If you don't want it, delete `.mcp.json` or the `notion` entry. If it isn't picked up, add the same URL as an HTTP MCP server manually.
- **claude.ai:** add Notion from the connector directory, or as a custom connector with the URL above.
- **ChatGPT / Codex:** the `.codex-plugin/plugin.json` points at `.mcp.json`; authenticate when prompted (for the Codex CLI: `codex mcp login notion`).

## What Atlas touches
Only databases you name. The connection can see what your Notion account can see, so use a dedicated workspace or teamspace if you want a smaller blast radius. Suggested layout: `skills/notion-sync/references/notion-schema.md`.

## No connection?
`python skills/notion-sync/scripts/export_notion_csv.py --state atlas/state.json --out atlas/notion-export/` and import the CSVs into Notion databases.
