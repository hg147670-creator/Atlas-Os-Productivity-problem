# Connect Google Calendar

Google provides a remote MCP server for Calendar. It uses OAuth 2.0 with a client **you** create, so the plugin cannot bundle a ready-made connection and never contains credentials.

**Server:** `https://calendarmcp.googleapis.com/mcp/v1` (Streamable HTTP)
**Tools exposed by Google:** list_calendars, list_events, get_event, create_event, update_event, delete_event, respond_to_event, suggest_time.

## Steps (from Google's guide - check it for the latest)
1. In a Google Cloud project, enable the **Google Calendar API** (`gcloud services enable calendar-json.googleapis.com --project=PROJECT_ID`) and the Calendar MCP service as described in Google's "Configure the Calendar MCP server" page.
2. Configure the OAuth consent screen, and choose the narrowest scopes you need.
3. Create an **OAuth 2.0 client ID** of type *Web application*.
   - For **Claude** (claude.ai or Claude Desktop): add the redirect URI `https://claude.ai/api/mcp/auth_callback`.
   - For **ChatGPT/Codex** or other clients: use the redirect URI your client displays when you add a custom MCP server.
4. Copy the client ID and secret.
5. **Claude:** Settings > Connectors > *Add custom connector*; name `Google Calendar`; URL above; under Advanced settings enter the client ID and secret. Google's guide says this requires a Claude Enterprise, Pro, Max, or Team plan.
   **Other clients:** add a remote MCP server named `calendar` with the URL above, transport Streamable HTTP, OAuth with your client ID/secret.
6. Test with: "What's on my calendar tomorrow?"

## Safety
- Connected clients can read, change, and delete calendar data. Connect only clients you trust.
- Event text from other people can contain hidden instructions (indirect prompt injection). Atlas treats event content as data and asks before every write.
- Keep the client secret out of notes, repos, and chat.

No calendar connection? Atlas still works from a pasted agenda and exports `.ics` files.
