---
description: Process the inbox with PARA
argument-hint: 
---

Use the knowledge-capture skill to triage the inbox; propose moves in a table and ask before applying.

User input: $ARGUMENTS
