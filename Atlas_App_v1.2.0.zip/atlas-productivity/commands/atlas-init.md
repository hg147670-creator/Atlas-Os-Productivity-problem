---
description: Initialize Atlas state (atlas/state.json) in this workspace
argument-hint: [north star goal]
---

Use the productivity-os skill. Create atlas/state.json with scripts/state.py init if it does not exist (never overwrite), then ask for the user's north-star goal and work-hour preferences and save them after confirmation.

User input: $ARGUMENTS
