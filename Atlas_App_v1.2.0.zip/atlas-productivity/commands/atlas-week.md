---
description: Weekly review and next week's 3 outcomes
argument-hint: [optional notes on the week]
---

Use the weekly-review skill to run the weekly review.

User input: $ARGUMENTS
