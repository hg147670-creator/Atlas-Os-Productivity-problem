---
description: Evidence-based research with citations
argument-hint: <question or decision>
---

Use the deep-research skill. State whether you are in quick or deep mode.

User input: $ARGUMENTS
