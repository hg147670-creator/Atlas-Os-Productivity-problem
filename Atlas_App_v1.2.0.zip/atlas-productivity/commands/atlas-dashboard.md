---
description: Build the productivity dashboard
argument-hint: 
---

Use the dashboard skill to build the dashboard from atlas/state.json.

User input: $ARGUMENTS
