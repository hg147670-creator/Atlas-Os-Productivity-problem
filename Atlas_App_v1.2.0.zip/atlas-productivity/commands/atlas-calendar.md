---
description: Read calendar, find free time, propose blocks
argument-hint: [date or task to schedule]
---

Use the calendar-sync skill. Create, move, or delete events only after confirming the exact list with the user.

User input: $ARGUMENTS
