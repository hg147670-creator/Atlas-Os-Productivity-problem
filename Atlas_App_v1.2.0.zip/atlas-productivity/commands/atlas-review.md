---
description: Monthly, quarterly, or annual review
argument-hint: [monthly|quarterly|annual]
---

Use the periodic-review skill in the requested mode (ask which if not given).

User input: $ARGUMENTS
