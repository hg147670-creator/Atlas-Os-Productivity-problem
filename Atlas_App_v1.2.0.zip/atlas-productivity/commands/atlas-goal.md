---
description: Turn a goal into a measurable plan
argument-hint: <goal>
---

Use the goal-planning skill to build the plan.

User input: $ARGUMENTS
