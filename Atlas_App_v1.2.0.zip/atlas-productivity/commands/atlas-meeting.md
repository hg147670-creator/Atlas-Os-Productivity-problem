---
description: Meeting prep or notes to actions
argument-hint: [notes or topic]
---

Use the meeting-notes skill.

User input: $ARGUMENTS
