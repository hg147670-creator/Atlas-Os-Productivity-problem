---
description: Make or log a decision
argument-hint: <decision>
---

Use the decision-log skill.

User input: $ARGUMENTS
