---
description: Sync Atlas with Notion (dry-run first)
argument-hint: [what to sync]
---

Use the notion-sync skill. Show a dry-run diff and get confirmation before any write.

User input: $ARGUMENTS
