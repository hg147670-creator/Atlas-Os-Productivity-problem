---
description: Design or review habits and streaks
argument-hint: [habit]
---

Use the habit-tracker skill.

User input: $ARGUMENTS
