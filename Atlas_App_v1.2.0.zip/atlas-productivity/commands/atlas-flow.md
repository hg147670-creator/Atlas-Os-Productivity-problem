---
description: Design or automate a workflow
argument-hint: <process>
---

Use the workflow-design skill.

User input: $ARGUMENTS
