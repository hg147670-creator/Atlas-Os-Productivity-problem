---
description: Capture a note or idea to the inbox
argument-hint: <text>
---

Use the knowledge-capture skill: capture the text to the inbox exactly as given, then confirm what was stored.

User input: $ARGUMENTS
