---
description: Start a deep-work block
argument-hint: [task]
---

Use the focus-session skill.

User input: $ARGUMENTS
