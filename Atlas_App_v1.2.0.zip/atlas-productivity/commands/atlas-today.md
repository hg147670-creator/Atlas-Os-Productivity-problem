---
description: Plan today: 3 outcomes, time blocks, capacity check
argument-hint: [available hours, fixed commitments]
---

Use the daily-planning skill to run today's planning session.

User input: $ARGUMENTS
