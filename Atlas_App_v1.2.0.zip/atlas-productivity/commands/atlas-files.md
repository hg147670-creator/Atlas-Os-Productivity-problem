---
description: Analyze files and extract decisions, tasks, risks
argument-hint: <what you want from the files>
---

Use the file-intelligence skill on the files the user provided or referenced.

User input: $ARGUMENTS
