# Changelog

## 0.3.0
- New skills: `periodic-review` (monthly/quarterly/annual), `calendar-sync`, `notion-sync` (16 skills total).
- Integrations: bundled Notion MCP (`.mcp.json`), Google Calendar setup guide + template (needs user-created OAuth client), `mcpServers` in the Codex manifest.
- Scripts: `free_slots.py`, `time_audit.py`, `export_notion_csv.py`; state gained `reviews` and `integrations`, plus `notion_id` / `calendar_event_id` link fields.
- Safety: all skills now treat external text (calendar, Notion, files, web) as data, never instructions; sync requires dry-run + confirmation, no deletes by default.
- Commands: `/atlas-calendar`, `/atlas-notion`, `/atlas-review`. Evals: 18 cases.

## 0.2.0
- Split the single skill into 13 focused skills with a router (`productivity-os`).
- Added persistent state (`atlas/state.json`) with three storage modes (files, memory, portable block).
- Added 14 slash commands, 6 templates, 5 scripts (state, capacity check, ICS export, habit stats, dashboard), evals, selftest.
- New features: decision log, focus sessions, habit tracking, meeting notes, inbox triage, estimate-accuracy tracking, capacity check with buffer factor, real HTML dashboard.
- Cross-platform: Claude (`.claude-plugin`) + Codex/ChatGPT (`.codex-plugin`) manifests generated from `manifest.source.json`; removed ChatGPT-only wording.
- Fixed: duplicated manifests could drift; skill descriptions were too narrow to trigger reliably (now include Vietnamese triggers).

## 0.1.0
- Initial single-skill release.
