# Atlas Productivity OS (v0.3.0)

A cross-platform productivity plugin for **Claude** and **ChatGPT/Codex**. It uses the shared *Agent Skills* format (`skills/<name>/SKILL.md`), so the same skill files work on both.

## What's inside
| Skill | Purpose |
|---|---|
| `productivity-os` | Router, capability check, persistent state (`atlas/state.json`) |
| `daily-planning` | 3 outcomes, time-blocking, capacity check, `.ics` export |
| `weekly-review` | Retro, cause diagnosis, estimate accuracy, next week's 3 outcomes |
| `goal-planning` | Goal -> milestones, pre-mortem, weekly cadence, OKR option |
| `deep-research` | Quick/deep research, source hierarchy, confidence, citations |
| `file-intelligence` | Traceable extraction from files, conflict flagging |
| `knowledge-capture` | Fast capture, inbox triage, PARA, atomic notes |
| `workflow-design` | Automation spec, payback check, least-privilege, confirmations |
| `decision-log` | Options/criteria, pre-mortem, decision records, review dates |
| `focus-session` | Deep-work block, friction removal, distraction parking lot |
| `habit-tracker` | Tiny habits, streaks and rates from real logs only |
| `meeting-notes` | Prep, minutes, actions with owners, follow-up draft |
| `dashboard` | Self-contained HTML snapshot from state |
| `periodic-review` | Monthly / quarterly / annual review: scorecard, area balance, time audit, portfolio keep/kill, next-period reset |
| `calendar-sync` | Read calendar, find free slots, propose blocks, create/move events only after confirmation |
| `notion-sync` | Dry-run diff then sync tasks/projects/inbox/decisions/reviews with Notion; CSV fallback |

Also: 17 slash commands (`commands/`, Claude Code), templates (`skills/*/assets/`), stdlib-only Python scripts (`skills/*/scripts/`), evals (`evals/evals.json`).

## Install
- **Claude Code / Cowork:** add this folder as a local plugin (or via your marketplace). Skills and `/atlas-*` commands are auto-discovered from `.claude-plugin/plugin.json`.
- **claude.ai:** upload individual skill folders (zip each `skills/<name>/`) in Settings > Capabilities > Skills. Slash commands are not used there; just name the skill or describe the task.
- **ChatGPT / Codex:** install the folder as a plugin using `.codex-plugin/plugin.json` (starter prompts come from `interface.defaultPrompt`). Check your workspace's current plugin docs, since availability differs by plan.

## Integrations (Calendar and Notion)
- **Notion:** `.mcp.json` registers Notion's hosted MCP server (`https://mcp.notion.com/mcp`, OAuth, no tokens in the plugin). Codex/ChatGPT picks it up via `mcpServers` in `.codex-plugin/plugin.json`; Claude Code auto-loads `.mcp.json`. Remove the file if you don't want it. Details: `integrations/notion.md`.
- **Google Calendar:** Google's remote MCP server needs an OAuth client that you create, so it is **not** bundled. Follow `integrations/google-calendar.md` (server `https://calendarmcp.googleapis.com/mcp/v1`). Without it Atlas plans from a pasted agenda and exports `.ics`.
- Both skills read each tool's schema at runtime instead of hard-coding tool names, show a dry run or exact list first, and never write, move, or delete without your confirmation. Calendar and Notion text is treated as untrusted data (prompt-injection safe).
- The portable root `plugin.json` does not declare MCP servers: OpenAI's docs describe a separate `mcp.json` format for portable packages that I could not verify, so I left it out rather than guess.

## Persistence (works everywhere)
1. **Files** - `atlas/state.json` in the workspace (needs file access).
2. **Memory tool** - durable user-stated facts only.
3. **Portable** - Atlas prints a JSON "state block" to paste next session.

Initialize with `/atlas-init` or `python skills/productivity-os/scripts/state.py init`. Schema: `skills/productivity-os/references/state-schema.md`.

## Maintaining
- Edit `manifest.source.json`, then run `python scripts/sync_manifests.py` - never hand-edit the three generated manifests.
- Run `python scripts/selftest.py` after changing any script (Python 3.8+, no dependencies).
- Skills are self-contained (scripts/templates live inside each skill) so individual skills still work when installed alone; the optional state helper is referenced as `../productivity-os/scripts/state.py` with a manual fallback.

## Safety defaults
No invented tasks, metrics, or completed actions; no claim of saving/sending without tool confirmation; confirmation required before any external side effect; no secrets in notes or state.
