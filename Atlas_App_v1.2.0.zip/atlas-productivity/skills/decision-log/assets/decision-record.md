# Decision record - {{short title}}

**Date:** | **Decider:** | **Reversible?** yes / no | **Review on:** 

## Context
## Options considered
| Option | Pros | Cons | Unknowns |
|---|---|---|---|

## Decision
## Why (criteria and trade-offs)
## Assumptions that must hold
- 
## Risks and mitigations (pre-mortem)
- 
## Expected outcome / how we'll know
