# {{meeting title}} - {{date}}
**Attendees:** | **Purpose:** | **Decision needed:** 

## Agenda
| Time | Topic | Owner |
|---|---|---|

## Decisions
- 

## Actions
| Action | Owner | Due | Done when |
|---|---|---|---|

## Open questions
- 

## Follow-up message (draft, not sent)
