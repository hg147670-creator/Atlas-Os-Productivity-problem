#!/usr/bin/env python3
"""Habit stats from atlas/state.json. Usage: habit_stats.py --state atlas/state.json [--today YYYY-MM-DD]"""
import argparse, json, datetime as dt

def parse(log):
    out = set()
    for d in log:
        try: out.add(dt.date.fromisoformat(d))
        except ValueError: pass
    return out

def streaks(days, today, target_per_week):
    """Current and best streak in days. One isolated miss is forgiven when the week's target is still reachable."""
    if not days: return 0, 0
    start = min(days); cur = best = 0; misses = 0; d = start
    while d <= today:
        if d in days: cur += 1; misses = 0; best = max(best, cur)
        else:
            misses += 1
            week_start = d - dt.timedelta(days=d.weekday())
            done = sum(1 for k in days if week_start <= k <= d)
            left = (week_start + dt.timedelta(days=6) - d).days
            reachable = done + left >= target_per_week
            if misses >= 2 or not reachable:
                if not (d == today and misses == 1): cur = 0
        d += dt.timedelta(days=1)
    return cur, best

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--state", default="atlas/state.json"); ap.add_argument("--today")
    a = ap.parse_args()
    today = dt.date.fromisoformat(a.today) if a.today else dt.date.today()
    habits = json.load(open(a.state, encoding="utf-8")).get("habits", [])
    if not habits: print("No habits in state."); return
    print(f"{'habit':<24}{'streak':>7}{'best':>6}{'week':>8}{'28d %':>8}")
    for h in habits:
        days = parse(h.get("log", [])); tgt = int(h.get("target_per_week", 5))
        cur, best = streaks(days, today, tgt)
        ws = today - dt.timedelta(days=today.weekday())
        wk = sum(1 for d in days if ws <= d <= today)
        w28 = sum(1 for d in days if today - dt.timedelta(days=27) <= d <= today)
        rate = round(100 * w28 / min(28, max(1, (today - min(days)).days + 1))) if days else 0
        print(f"{h.get('name','?')[:23]:<24}{cur:>7}{best:>6}{f'{wk}/{tgt}':>8}{rate:>7}%")

if __name__ == "__main__": main()
