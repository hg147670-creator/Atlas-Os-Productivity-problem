# Project brief - {{name}}

**Outcome:** 
**Why it matters:** 
**Success criteria:** 1) ... 2) ...
**Target / review date:** 
**Area:** 

## Milestones
| # | Milestone | Done when | Due | Depends on |
|---|---|---|---|---|

## Risks (pre-mortem)
| Risk | Mitigation | Early-warning signal |
|---|---|---|

## Weekly actions (next 2 weeks)
- 

## Smallest next step (today, <15 min)
- 

## Rescope / stop if
- 

## Review cadence
- 
