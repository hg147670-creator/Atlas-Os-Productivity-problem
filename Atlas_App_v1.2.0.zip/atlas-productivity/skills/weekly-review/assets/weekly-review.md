# Weekly review - {{YYYY-Www}}

## Planned vs achieved
| Outcome | Done? | Evidence |
|---|---|---|

## Misses and main cause
| Miss | Cause (goal / overcommit / dependency / interruption / estimate / priority) | Pattern? |
|---|---|---|

## Estimate accuracy
Typical actual/estimate ratio: 

## Projects: continue / pause / finish / drop
- 

## Decisions needed
- 

## Next week - 3 outcomes
1. outcome - done when - first action - starts
2.
3.

## One system improvement
Change: 
Signal it worked: 

Next review: 
