#!/usr/bin/env python3
"""Build a self-contained HTML dashboard from atlas/state.json. Usage: build_dashboard.py --state S --out O"""
import argparse, json, html, datetime as dt

def e(x): return html.escape(str(x if x is not None else ""))

def date_or_none(s):
    try: return dt.date.fromisoformat(s) if s else None
    except ValueError: return None

def streak(log, today):
    days = set(filter(None, (date_or_none(d) for d in log))); n = 0; d = today
    if d not in days: d -= dt.timedelta(days=1)
    while d in days: n += 1; d -= dt.timedelta(days=1)
    return n

def card(title, body): return f'<section class="card"><h2>{e(title)}</h2>{body}</section>'
def ul(items): return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>" if items else ""

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--state", default="atlas/state.json")
    ap.add_argument("--out", default="atlas/dashboard.html"); ap.add_argument("--today"); a = ap.parse_args()
    s = json.load(open(a.state, encoding="utf-8"))
    today = date_or_none(a.today) or dt.date.today()
    cards = []
    if s.get("north_star"): cards.append(card("North star", f"<p class='big'>{e(s['north_star'])}</p>"))
    tasks = [t for t in s.get("tasks", []) if t.get("status") == "open"]
    def key(t): d = date_or_none(t.get("due")); return (d is None, d or dt.date.max)
    top = sorted(tasks, key=key)[: int(s.get("preferences", {}).get("max_daily_priorities", 3))]
    if top: cards.append(card("Top priorities", ul(f"{e(t.get('title'))}" + (f" <span class='muted'>due {e(t['due'])}</span>" if t.get("due") else "") for t in top)))
    projs = [p for p in s.get("projects", []) if p.get("status") == "active"]
    if projs:
        rows = []
        for p in projs:
            ms = [m for m in p.get("milestones", []) if not m.get("done")]
            nm = ms[0] if ms else None; done = sum(1 for m in p.get("milestones", []) if m.get("done")); tot = len(p.get("milestones", []))
            rows.append(f"<li><b>{e(p.get('name'))}</b>" + (f" <span class='muted'>{done}/{tot} milestones</span>" if tot else "")
                        + (f"<br>Next milestone: {e(nm.get('title'))}" + (f" ({e(nm['due'])})" if nm.get('due') else "") if nm else "")
                        + (f"<br>Next action: {e(p['next_action'])}" if p.get("next_action") else "") + "</li>")
        cards.append(card("Active projects", "<ul>" + "".join(rows) + "</ul>"))
    dl = []
    for t in tasks: dl.append((date_or_none(t.get("due")), t.get("title")))
    for p in projs:
        if date_or_none(p.get("deadline")): dl.append((date_or_none(p["deadline"]), "Project: " + str(p.get("name"))))
        for m in p.get("milestones", []):
            if not m.get("done") and date_or_none(m.get("due")): dl.append((date_or_none(m["due"]), "Milestone: " + str(m.get("title"))))
    dl = sorted((d, t) for d, t in dl if d and d <= today + dt.timedelta(days=14))
    BAD = '<span class="bad">OVERDUE</span> '
    if dl: cards.append(card("Deadlines (next 14 days)", ul((BAD if d < today else "") + e(d.isoformat()) + " - " + e(t) for d, t in dl)))
    hs = s.get("habits", [])
    if any(h.get("log") for h in hs): cards.append(card("Habits", ul(f"{e(h.get('name'))}: streak {streak(h.get('log', []), today)} d" for h in hs if h.get("log"))))
    if s.get("inbox"): cards.append(card("Inbox", f"<p class='big'>{len(s['inbox'])}</p><p class='muted'>items awaiting triage</p>"))
    dec = [d for d in s.get("decisions", []) if d.get("status") == "open"]
    due = [d for d in dec if date_or_none(d.get("review_on")) and date_or_none(d["review_on"]) <= today]
    if due: cards.append(card("Decisions to review", ul(e(d.get("decision")) for d in due)))
    wk = s.get("weekly", [])
    if wk: cards.append(card("Last weekly review", f"<p>{e(wk[-1].get('week'))}: {e(wk[-1].get('lesson') or wk[-1].get('result'))}</p>"))
    if not cards: cards.append(card("Nothing to show", "<p>State has no data yet. Add goals, projects, or tasks first.</p>"))
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Atlas dashboard</title><style>
:root{{--bg:#f6f7f9;--fg:#1d2330;--card:#fff;--mut:#6b7385;--bd:#e3e6ec;--bad:#c0392b}}
@media (prefers-color-scheme:dark){{:root{{--bg:#12151c;--fg:#e8ebf2;--card:#1b2030;--mut:#9aa3b8;--bd:#2a3146;--bad:#ff7b6b}}}}
body{{margin:0;padding:20px;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
h1{{font-size:20px;margin:0 0 4px}}.sub{{color:var(--mut);margin-bottom:16px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}}
.card{{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:14px 16px}}
h2{{font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut);margin:0 0 8px}}
ul{{margin:0;padding-left:18px}}li{{margin:4px 0}}.big{{font-size:22px;font-weight:600;margin:0}}.muted{{color:var(--mut)}}.bad{{color:var(--bad);font-weight:600}}
</style></head><body><h1>Atlas dashboard</h1>
<div class="sub">Snapshot as of {e(s.get('updated') or 'unknown')} (rendered {e(today.isoformat())}) - not a live view</div>
<div class="grid">{''.join(cards)}</div></body></html>"""
    with open(a.out, "w", encoding="utf-8") as f: f.write(page)
    print(f"wrote {a.out}")

if __name__ == "__main__": main()
