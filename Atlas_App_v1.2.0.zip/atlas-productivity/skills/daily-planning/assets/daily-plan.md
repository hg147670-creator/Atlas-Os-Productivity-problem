# Daily plan - {{date}}

**Available:** {{hours}} h  |  **Fixed commitments:** {{fixed}}  |  **Energy:** {{energy}}

## Outcomes (max 3)
1. {{outcome}} - why: {{why}} - first action: {{first_action}} - est: {{est}} min
2.
3.

## Schedule
| Time | Block | First action |
|---|---|---|
| | | |

## Risks
- 

## Deferred today
- 

## Shutdown (10 min)
- Done:
- Rolls over:
- Tomorrow's first action:
