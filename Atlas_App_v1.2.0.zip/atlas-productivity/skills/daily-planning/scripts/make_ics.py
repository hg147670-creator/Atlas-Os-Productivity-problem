#!/usr/bin/env python3
"""Create an .ics file from JSON blocks on stdin: [{"title","start":"YYYY-MM-DDTHH:MM","duration_min":50,"notes":""}].
Times are written as floating local time (no timezone), so they import in the user's local zone."""
import argparse, json, sys, uuid, datetime as dt

def esc(s): return str(s).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

def fold(line):
    out = []
    while len(line.encode("utf-8")) > 74:
        cut = 70
        while len(line[:cut].encode("utf-8")) > 74: cut -= 1
        out.append(line[:cut]); line = " " + line[cut:]
    out.append(line); return out

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", required=True); ap.add_argument("--input")
    a = ap.parse_args()
    blocks = json.load(open(a.input) if a.input else sys.stdin)
    stamp = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Atlas Productivity OS//EN", "CALSCALE:GREGORIAN"]
    for b in blocks:
        s = dt.datetime.fromisoformat(b["start"]); e = s + dt.timedelta(minutes=int(b.get("duration_min", 50)))
        lines += ["BEGIN:VEVENT", f"UID:{uuid.uuid4()}@atlas", f"DTSTAMP:{stamp}",
                  f"DTSTART:{s.strftime('%Y%m%dT%H%M%S')}", f"DTEND:{e.strftime('%Y%m%dT%H%M%S')}",
                  f"SUMMARY:{esc(b['title'])}"]
        if b.get("notes"): lines.append(f"DESCRIPTION:{esc(b['notes'])}")
        lines.append("END:VEVENT")
    lines.append("END:VCALENDAR")
    folded = [seg for l in lines for seg in fold(l)]
    with open(a.out, "w", encoding="utf-8", newline="") as f: f.write("\r\n".join(folded) + "\r\n")
    print(f"wrote {a.out} ({len(blocks)} events)")

if __name__ == "__main__": main()
