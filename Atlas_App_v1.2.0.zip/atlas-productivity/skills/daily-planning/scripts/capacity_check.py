#!/usr/bin/env python3
"""Capacity check. Reads JSON list [{"title","est_min"}] (priority order) from stdin or --tasks.
Defers tail tasks until buffered load <= max-load of available time."""
import argparse, json, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--available-hours", type=float, required=True)
    ap.add_argument("--buffer", type=float, default=1.5)
    ap.add_argument("--max-load", type=float, default=0.65)
    ap.add_argument("--tasks")
    a = ap.parse_args()
    if a.available_hours <= 0: sys.exit("available-hours must be > 0")
    tasks = json.load(open(a.tasks) if a.tasks else sys.stdin)
    avail = a.available_hours * 60
    budget = avail * a.max_load
    keep, defer, split, used = [], [], [], 0.0
    for t in tasks:
        cost = float(t["est_min"]) * a.buffer
        if cost > budget: split.append(t["title"])  # cannot fit even alone: shrink or split it
        if used + cost <= budget: keep.append(t["title"]); used += cost
        else: defer.append(t["title"])
    raw = sum(float(t["est_min"]) for t in tasks)
    out = {"available_min": round(avail), "budget_min": round(budget),
           "raw_est_min": round(raw), "buffered_est_min": round(raw * a.buffer),
           "load_if_all": round(raw * a.buffer / avail, 2),
           "verdict": "fits" if not defer else "overloaded",
           "keep": keep, "defer": defer, "split_or_shrink": split, "kept_buffered_min": round(used)}
    print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == "__main__": main()
