# {{Monthly|Quarterly|Annual}} review - {{period, e.g. 2026-Q4}}

## Scorecard
| Goal / KR | Target | Actual | Status | Evidence |
|---|---|---|---|---|

## Area balance (user-rated 1-10)
| Area | Score | Evidence | Neglected? |
|---|---|---|---|

## Time audit (calendar, by event titles - heuristic)
| Area | Hours | % | Matches stated priority? |
|---|---|---|---|
Uncategorized:

## Project portfolio
| Project | Progress vs plan | Remaining effort | Value | Decision (accelerate / keep / pause / kill) |
|---|---|---|---|---|

## Habits and decisions
- Habits: keep / shrink / drop
- Decisions reviewed:

## Patterns
- Recurring causes:
- Start:
- Stop:
- Continue:

## Next period
**Theme:** 
| Goal / OKR | Key result (measurable) | First action | Est hours |
|---|---|---|---|
Capacity: available h x load = budget h; planned (buffered) = h -> fits / cut:
**Not doing:** 

## Annual only
- Year in one page (wins, lessons, surprises):
- 3-year direction check:
- Theme for the year:

**Next review:** 
