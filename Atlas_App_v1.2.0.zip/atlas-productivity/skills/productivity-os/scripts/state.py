#!/usr/bin/env python3
"""Atlas state helper (stdlib only).
Usage:
  python state.py init [--path atlas/state.json]
  python state.py validate [--path ...]
  python state.py capture "text" [--source S] [--path ...]
  python state.py habit-log HABIT_ID [YYYY-MM-DD] [--path ...]
  python state.py summary [--path ...]
"""
import argparse, json, os, sys, datetime as dt

DEFAULT = {
    "version": 1, "updated": "", "north_star": "",
    "preferences": {"work_hours": "09:00-17:00", "focus_block_min": 50, "buffer_factor": 1.5,
                    "max_load": 0.65, "max_daily_priorities": 3, "language": "auto"},
    "areas": [], "projects": [], "tasks": [], "inbox": [], "habits": [], "decisions": [], "weekly": [], "reviews": [],
    "integrations": {"calendar": {"calendar_id": "primary", "event_prefix": "[Atlas] "},
                     "notion": {"direction": "atlas-to-notion", "last_sync": None}},
}
LISTS = ["areas", "projects", "tasks", "inbox", "habits", "decisions", "weekly", "reviews"]
ENUMS = {"projects": ("status", {"active", "paused", "done"}),
         "tasks": ("status", {"open", "done", "deferred"}),
         "decisions": ("status", {"open", "reviewed", "reversed"})}

def today(): return dt.date.today().isoformat()

def load(path):
    with open(path, encoding="utf-8") as f: return json.load(f)

def save(path, data):
    data["updated"] = today()
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def validate(data):
    errs = []
    if data.get("version") != 1: errs.append("version must be 1")
    for k in LISTS:
        if not isinstance(data.get(k, []), list): errs.append(f"{k} must be a list"); continue
        ids = [x.get("id") for x in data.get(k, []) if isinstance(x, dict) and "id" in x]
        if len(ids) != len(set(ids)): errs.append(f"duplicate ids in {k}")
    for k, (field, allowed) in ENUMS.items():
        for x in data.get(k, []):
            if x.get(field) not in allowed: errs.append(f"{k}:{x.get('id')} bad {field}={x.get(field)!r}")
    pids = {p.get("id") for p in data.get("projects", [])}
    for t in data.get("tasks", []):
        if t.get("project") and t["project"] not in pids: errs.append(f"task {t.get('id')} -> unknown project {t['project']}")
    for h in data.get("habits", []):
        for d in h.get("log", []):
            try: dt.date.fromisoformat(d)
            except ValueError: errs.append(f"habit {h.get('id')} bad date {d!r}")
    return errs

def next_id(items, prefix):
    n = 0
    for x in items:
        s = str(x.get("id", ""))
        if s.startswith(prefix) and s[len(prefix):].isdigit(): n = max(n, int(s[len(prefix):]))
    return f"{prefix}{n+1}"

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("cmd"); ap.add_argument("args", nargs="*")
    ap.add_argument("--path", default="atlas/state.json"); ap.add_argument("--source", default="")
    a = ap.parse_args()
    if a.cmd == "init":
        if os.path.exists(a.path): print(f"exists: {a.path} (not overwritten)"); return 0
        save(a.path, json.loads(json.dumps(DEFAULT))); print(f"created {a.path}"); return 0
    if not os.path.exists(a.path): print(f"missing {a.path}; run init", file=sys.stderr); return 2
    data = load(a.path)
    if a.cmd == "validate":
        errs = validate(data); print("OK" if not errs else "\n".join(errs)); return 1 if errs else 0
    if a.cmd == "capture":
        if not a.args: print("text required", file=sys.stderr); return 2
        item = {"id": next_id(data["inbox"], "i"), "captured": today(), "text": " ".join(a.args), "source": a.source}
        data["inbox"].append(item); save(a.path, data); print(f"captured {item['id']}"); return 0
    if a.cmd == "habit-log":
        hid = a.args[0] if a.args else None; d = a.args[1] if len(a.args) > 1 else today()
        dt.date.fromisoformat(d)
        h = next((x for x in data["habits"] if x.get("id") == hid), None)
        if not h: print(f"unknown habit {hid}", file=sys.stderr); return 2
        if d in h.setdefault("log", []): print("already logged"); return 0
        h["log"].append(d); h["log"].sort(); save(a.path, data); print(f"logged {hid} {d}"); return 0
    if a.cmd == "summary":
        print(f"updated={data.get('updated')} north_star={data.get('north_star')!r}")
        print("active projects:", sum(1 for p in data["projects"] if p.get("status") == "active"))
        print("open tasks:", sum(1 for t in data["tasks"] if t.get("status") == "open"))
        print("inbox:", len(data["inbox"]), "| habits:", len(data["habits"]), "| open decisions:",
              sum(1 for d in data["decisions"] if d.get("status") == "open")); return 0
    print("unknown command", file=sys.stderr); return 2

if __name__ == "__main__": sys.exit(main())
