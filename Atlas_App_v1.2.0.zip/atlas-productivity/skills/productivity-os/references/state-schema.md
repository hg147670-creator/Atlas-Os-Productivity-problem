# Atlas state schema (v1)

File: `atlas/state.json`. All dates ISO `YYYY-MM-DD`. Unknown fields must be preserved on write.

```json
{
  "version": 1,
  "updated": "2026-01-01",
  "north_star": "",
  "preferences": {
    "work_hours": "09:00-17:00",
    "focus_block_min": 50,
    "buffer_factor": 1.5,
    "max_load": 0.65,
    "max_daily_priorities": 3,
    "language": "auto"
  },
  "areas": [{"id": "a1", "name": "Health", "standard": "Exercise 3x/week"}],
  "projects": [{
    "id": "p1", "name": "", "outcome": "", "area": "a1",
    "status": "active", "deadline": null, "next_action": "",
    "milestones": [{"title": "", "due": null, "done": false}]
  }],
  "tasks": [{
    "id": "t1", "title": "", "project": "p1", "est_min": 30,
    "actual_min": null, "due": null, "status": "open", "energy": "med"
  }],
  "inbox": [{"id": "i1", "captured": "2026-01-01", "text": "", "source": ""}],
  "habits": [{
    "id": "h1", "name": "", "cue": "", "minimum": "",
    "target_per_week": 5, "log": ["2026-01-01"]
  }],
  "decisions": [{
    "id": "d1", "date": "2026-01-01", "decision": "", "why": "",
    "assumptions": [], "review_on": null, "status": "open"
  }],
  "weekly": [{"week": "2026-W01", "outcomes": [], "result": "", "lesson": ""}],
  "reviews": [{
    "id": "r1", "period": "2026-Q4", "type": "quarterly",
    "result": "", "lesson": "", "next_goals": []
  }],
  "integrations": {
    "calendar": {"calendar_id": "primary", "event_prefix": "[Atlas] "},
    "notion": {"direction": "atlas-to-notion", "last_sync": null}
  }
}
```

Enums: project.status = active|paused|done; task.status = open|done|deferred; task.energy = low|med|high; decision.status = open|reviewed|reversed.
Optional per-item link fields written by integrations: `notion_id` (tasks, projects, inbox, decisions, reviews) and `calendar_event_id` (tasks). `reviews[].type` = weekly|monthly|quarterly|annual. Never store tokens, client secrets, or private event/page content in `integrations`.
IDs are short strings unique within their list. `est_min` and `actual_min` enable estimate-accuracy tracking in `weekly-review`.
