#!/usr/bin/env python3
"""Export Atlas state to CSV files that can be imported into Notion databases (fallback when Notion is not connected).
Usage: export_notion_csv.py --state atlas/state.json --out atlas/notion-export/"""
import argparse, csv, json, os

def j(x): return "; ".join(map(str, x)) if isinstance(x, list) else ("" if x is None else x)

SPEC = {
  "tasks": ("tasks.csv", ["Name", "Atlas ID", "Status", "Due", "Project", "Est min", "Actual min", "Energy"],
            lambda t, ctx: [t.get("title"), t.get("id"), t.get("status"), t.get("due"), ctx["projects"].get(t.get("project"), t.get("project")), t.get("est_min"), t.get("actual_min"), t.get("energy")]),
  "projects": ("projects.csv", ["Name", "Atlas ID", "Status", "Outcome", "Deadline", "Next action", "Area"],
               lambda p, ctx: [p.get("name"), p.get("id"), p.get("status"), p.get("outcome"), p.get("deadline"), p.get("next_action"), ctx["areas"].get(p.get("area"), p.get("area"))]),
  "inbox": ("inbox.csv", ["Name", "Atlas ID", "Captured", "Source"],
            lambda i, ctx: [i.get("text"), i.get("id"), i.get("captured"), i.get("source")]),
  "decisions": ("decisions.csv", ["Name", "Atlas ID", "Date", "Why", "Status", "Review on"],
                lambda d, ctx: [d.get("decision"), d.get("id"), d.get("date"), d.get("why"), d.get("status"), d.get("review_on")]),
  "reviews": ("reviews.csv", ["Name", "Atlas ID", "Type", "Result", "Lesson", "Next period goals"],
              lambda r, ctx: [r.get("period"), r.get("id"), r.get("type"), r.get("result"), r.get("lesson"), j(r.get("next_goals"))]),
}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--state", default="atlas/state.json"); ap.add_argument("--out", default="atlas/notion-export")
    a = ap.parse_args(); s = json.load(open(a.state, encoding="utf-8")); os.makedirs(a.out, exist_ok=True)
    ctx = {"projects": {p.get("id"): p.get("name") for p in s.get("projects", [])}, "areas": {x.get("id"): x.get("name") for x in s.get("areas", [])}}
    for key, (fn, cols, row) in SPEC.items():
        items = s.get(key, [])
        if not items: continue
        with open(os.path.join(a.out, fn), "w", encoding="utf-8", newline="") as f:
            wr = csv.writer(f); wr.writerow(cols)
            for it in items: wr.writerow([j(c) for c in row(it, ctx)])
        print(f"wrote {fn} ({len(items)} rows)")

if __name__ == "__main__": main()
