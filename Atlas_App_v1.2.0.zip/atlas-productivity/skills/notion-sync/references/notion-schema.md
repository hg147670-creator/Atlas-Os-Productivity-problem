# Suggested Notion databases

Titles are suggestions; map to whatever the user already has. Always keep an `Atlas ID` text property as the join key.

| Database | Properties |
|---|---|
| Atlas Tasks | Name (title), Atlas ID, Status (Open/Done/Deferred), Due (date), Project (relation or text), Est min (number), Actual min (number), Energy (Low/Med/High) |
| Atlas Projects | Name (title), Atlas ID, Status (Active/Paused/Done), Outcome (text), Deadline (date), Next action (text), Area (text) |
| Atlas Inbox | Name (title), Atlas ID, Captured (date), Source (text), Triage (Unprocessed/Task/Resource/Archive) |
| Atlas Decisions | Name (title), Atlas ID, Date, Why (text), Status (Open/Reviewed/Reversed), Review on (date) |
| Atlas Reviews | Name (title, e.g. 2026-Q4), Atlas ID, Type (Weekly/Monthly/Quarterly/Annual), Result (text), Lesson (text), Next period goals (text) |

Status values in Notion may be select or status properties; match the existing option names instead of creating new ones.
