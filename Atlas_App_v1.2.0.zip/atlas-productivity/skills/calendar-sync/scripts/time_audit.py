#!/usr/bin/env python3
"""Hours per area from calendar events, by keyword rules. Heuristic: it reflects how events were titled, not how time was really spent.
Events JSON on stdin or --events: [{"title","start","end"}]. Rules JSON via --rules: {"Area name": ["keyword", ...], ...}
Usage: time_audit.py --rules rules.json [--events events.json]"""
import argparse, json, sys, datetime as dt

def parse(s): return dt.datetime.fromisoformat(str(s).strip().replace("Z", "+00:00")).replace(tzinfo=None)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--rules", required=True); ap.add_argument("--events")
    a = ap.parse_args()
    rules = json.load(open(a.rules, encoding="utf-8"))
    events = json.load(open(a.events) if a.events else sys.stdin)
    totals, unc, counted, skipped = {k: 0.0 for k in rules}, {}, 0, 0
    for ev in events:
        if len(str(ev["start"])) <= 10: skipped += 1; continue  # all-day
        s, e = parse(ev["start"]), parse(ev["end"]); mins = max(0.0, (e - s).total_seconds() / 60)
        title = str(ev.get("title", "")).lower(); hit = None
        for area, kws in rules.items():
            if any(k.lower() in title for k in kws): hit = area; break
        counted += 1
        if hit: totals[hit] += mins
        else: unc[ev.get("title", "(untitled)")] = unc.get(ev.get("title", "(untitled)"), 0) + mins
    allm = sum(totals.values()) + sum(unc.values())
    out = {"events_counted": counted, "all_day_skipped": skipped, "total_hours": round(allm / 60, 1),
           "by_area_hours": {k: round(v / 60, 1) for k, v in totals.items()},
           "by_area_pct": {k: (round(100 * v / allm) if allm else 0) for k, v in totals.items()},
           "uncategorized_hours": round(sum(unc.values()) / 60, 1),
           "uncategorized_top": sorted(((round(v / 60, 1), k) for k, v in unc.items()), reverse=True)[:10]}
    print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == "__main__": main()
