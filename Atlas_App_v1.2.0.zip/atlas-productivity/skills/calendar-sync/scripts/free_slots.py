#!/usr/bin/env python3
"""Free slots for one day. Events JSON on stdin or --events: [{"title","start","end"}] (ISO, local time; offsets are dropped).
All-day entries (date only) are ignored unless {"blocking": true}.
Usage: free_slots.py --date 2026-01-08 [--work-hours 09:00-17:00] [--min-minutes 30] [--buffer-min 10] [--focus-min 50]"""
import argparse, json, sys, datetime as dt

def parse(s):
    s = s.strip().replace("Z", "+00:00")
    d = dt.datetime.fromisoformat(s)
    return d.replace(tzinfo=None)

def hm(s): h, m = s.split(":"); return int(h), int(m)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True); ap.add_argument("--work-hours", default="09:00-17:00")
    ap.add_argument("--min-minutes", type=int, default=30); ap.add_argument("--buffer-min", type=int, default=10)
    ap.add_argument("--focus-min", type=int, default=50); ap.add_argument("--events")
    a = ap.parse_args()
    day = dt.date.fromisoformat(a.date)
    s_, e_ = a.work_hours.split("-"); (sh, sm), (eh, em) = hm(s_), hm(e_)
    win_s = dt.datetime.combine(day, dt.time(sh, sm)); win_e = dt.datetime.combine(day, dt.time(eh, em))
    if win_e <= win_s: sys.exit("work-hours end must be after start")
    events = json.load(open(a.events) if a.events else sys.stdin)
    buf = dt.timedelta(minutes=a.buffer_min); busy = []
    for ev in events:
        if len(str(ev["start"])) <= 10 and not ev.get("blocking"): continue
        s, e = parse(str(ev["start"])), parse(str(ev["end"]))
        if e <= s: continue
        s, e = s - buf, e + buf
        if e <= win_s or s >= win_e: continue
        busy.append((max(s, win_s), min(e, win_e)))
    busy.sort(); merged = []
    for s, e in busy:
        if merged and s <= merged[-1][1]: merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else: merged.append((s, e))
    free, cur = [], win_s
    for s, e in merged:
        if s > cur: free.append((cur, s))
        cur = max(cur, e)
    if cur < win_e: free.append((cur, win_e))
    slots = [{"start": s.strftime("%H:%M"), "end": e.strftime("%H:%M"), "minutes": int((e - s).total_seconds() // 60)}
             for s, e in free if (e - s).total_seconds() >= a.min_minutes * 60]
    out = {"date": a.date, "work_hours": a.work_hours, "buffer_min": a.buffer_min, "slots": slots,
           "total_free_min": sum(x["minutes"] for x in slots),
           "focus_capable": [x for x in slots if x["minutes"] >= a.focus_min]}
    print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == "__main__": main()
