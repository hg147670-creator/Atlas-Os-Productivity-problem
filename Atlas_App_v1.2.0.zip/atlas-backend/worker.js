// Atlas AI gateway (Cloudflare Worker). Holds the Anthropic key, checks the subscription, applies a daily limit.
// Message bodies are never logged or stored.
const MODELS = new Set(['claude-sonnet-5-5', 'claude-haiku-5-5']);
const day = () => new Date().toISOString().slice(0, 10);
function cors(req, env) {
  const o = req.headers.get('origin') || '', ok = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim());
  return { 'access-control-allow-origin': ok.includes(o) ? o : ok[0] || '', 'vary': 'origin',
    'access-control-allow-headers': 'content-type,authorization', 'access-control-allow-methods': 'GET,POST,OPTIONS' };
}
const J = (obj, status, h) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json', ...h } });
const err = (msg, status, h) => J({ error: { message: msg } }, status, h);
async function license(req, env) {
  const key = (req.headers.get('authorization') || '').replace(/^Bearer\s+/i, '');
  if (!key) return null;
  const rec = await env.LICENSES.get('lic:' + key, 'json');
  if (!rec || rec.status !== 'active' || new Date(rec.expires) < new Date()) return { key, rec, active: false };
  return { key, rec, active: true };
}
export default {
  async fetch(req, env) {
    const h = cors(req, env), url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: h });
    if (url.pathname === '/admin/license' && req.method === 'POST') {
      if ((req.headers.get('authorization') || '') !== 'Bearer ' + env.ADMIN_TOKEN) return err('forbidden', 403, h);
      const b = await req.json(), k = b.key || 'ATLAS-' + [...crypto.getRandomValues(new Uint8Array(6))].map(x => x.toString(16).padStart(2, '0')).join('').replace(/(.{4})(.{4})(.{4})/, '$1-$2-$3').toUpperCase();
      const old = await env.LICENSES.get('lic:' + k, 'json'), base = Math.max(Date.now(), old ? new Date(old.expires).getTime() : 0);
      const rec = { status: b.status || 'active', expires: new Date(base + (+b.days || 30) * 864e5).toISOString(), daily_limit: +b.daily_limit || old?.daily_limit || 100, note: b.note || old?.note || '' };
      await env.LICENSES.put('lic:' + k, JSON.stringify(rec));
      return J({ key: k, ...rec }, 200, h);
    }
    const lic = await license(req, env);
    if (url.pathname === '/v1/status' && req.method === 'GET') {
      if (!lic) return err('missing license', 401, h);
      const used = +(await env.LICENSES.get(`use:${lic.key}:${day()}`) || 0);
      return J({ active: lic.active, expires: lic.rec?.expires || null, remaining_today: lic.active ? Math.max(0, lic.rec.daily_limit - used) : 0 }, 200, h);
    }
    if (url.pathname === '/v1/chat' && req.method === 'POST') {
      if (!lic || !lic.rec) return err('Mã đăng ký không hợp lệ', 401, h);
      if (!lic.active) return err('Đăng ký đã hết hạn hoặc bị hủy', 402, h);
      const uk = `use:${lic.key}:${day()}`, used = +(await env.LICENSES.get(uk) || 0);
      if (used >= lic.rec.daily_limit) return err('Đã hết lượt AI hôm nay', 429, h);
      let b; try { b = await req.json(); } catch { return err('bad json', 400, h); }
      if (!MODELS.has(b.model)) return err('model not allowed', 400, h);
      if (!Array.isArray(b.messages) || b.messages.length > 40 || String(b.system || '').length > 60000) return err('request too large', 400, h);
      await env.LICENSES.put(uk, String(used + 1), { expirationTtl: 172800 }); // soft limit (KV is not atomic)
      const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: b.model, system: b.system, messages: b.messages, max_tokens: Math.min(+b.max_tokens || 1500, 2000) }) });
      return new Response(await r.text(), { status: r.status, headers: { 'content-type': 'application/json', ...h } });
    }
    return err('not found', 404, h);
  }
};
