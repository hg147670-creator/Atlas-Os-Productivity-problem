# Atlas AI gateway

Untested starter (written without a Cloudflare account to run it against). It lets paying customers use AI without their own key: the app sends the license key, the Worker checks it and calls Anthropic with YOUR key.

## Deploy
1. `npm i -g wrangler` and `wrangler login`.
2. `wrangler kv namespace create LICENSES`, paste the id into `wrangler.toml`; set `ALLOWED_ORIGINS`.
3. `wrangler secret put ANTHROPIC_API_KEY` and `wrangler secret put ADMIN_TOKEN` (any long random string).
4. `wrangler deploy`, then put the Worker URL into `const PROXY=''` in `atlas-app/index.html`.

## Issue / extend a license (until payment webhooks are wired)
`curl -X POST $URL/admin/license -H "authorization: Bearer $ADMIN_TOKEN" -H "content-type: application/json" -d '{"days":30,"daily_limit":100,"note":"customer@email"}'`
Calling it again with `"key"` extends that license; `"status":"canceled"` disables it.

## Still to build
- Payment webhook: your payment provider calls an endpoint that runs the same logic on payment/renewal/cancel. Needs the provider's exact webhook format and signature check.
- Free-trial abuse limits, per-IP rate limits, usage cost alerts, a privacy policy that says chat text passes through your server (it is not stored or logged by this code).
